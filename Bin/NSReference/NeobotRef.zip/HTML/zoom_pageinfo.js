pageinfo = [[0,0,0,0,null],
	[0,0,0,0,null],
	[0,0,0,0,null],
	[0,0,0,0,null],
	[0,0,0,0,null],
	[0,0,0,0,null]];
pagedata = [ ["aliases.htm","Aliases","Aliases Top Next Points Rect ",""],
["movements.htm","Reference &#62; Movements","Movements",""],
["alias.htm","Reference &#62; Alias","Alias",""],
["sensors.htm","Reference &#62; Sensors","Sensors",""],
["syntax.htm","Reference &#62; Introduction","Introduction",""],
["basic_types.htm","Reference &#62; Basic Types","Basic Types",""]];
